---
name: Veloce Telemetry Studio
colors:
  surface: '#f9f9ff'
  surface-dim: '#d7dae4'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3fe'
  surface-container: '#ebedf8'
  surface-container-high: '#e6e8f2'
  surface-container-highest: '#e0e2ec'
  on-surface: '#181c23'
  on-surface-variant: '#46464a'
  inverse-surface: '#2d3038'
  inverse-on-surface: '#eef0fb'
  outline: '#77777b'
  outline-variant: '#c7c6ca'
  surface-tint: '#5f5e5f'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1c'
  on-primary-container: '#858384'
  inverse-primary: '#c8c6c7'
  secondary: '#526600'
  on-secondary: '#ffffff'
  secondary-container: '#c7ef2e'
  on-secondary-container: '#566a00'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e3'
  primary-fixed-dim: '#c8c6c7'
  on-primary-fixed: '#1c1b1c'
  on-primary-fixed-variant: '#474647'
  secondary-fixed: '#caf231'
  secondary-fixed-dim: '#afd500'
  on-secondary-fixed: '#171e00'
  on-secondary-fixed-variant: '#3d4c00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f9f9ff'
  on-background: '#181c23'
  surface-variant: '#e0e2ec'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.011em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.006em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  margin-mobile: 1.25rem
  margin-tablet: 2rem
  margin-desktop: 3rem
---

## Brand & Style

This design system converges the emotional allure of a high-end automotive atelier with the ruthless precision of a clinical telemetry laboratory. It serves discerning engineers, track specialists, and luxury automotive clientele who demand instantaneous diagnostics alongside an elevated, gallery-grade presentation.

The visual direction marries Apple-inspired studio minimalism with tactile engineering instrumentation:
- **Atmospheric Discipline:** Canvas backdrops transition through an imperceptible, multi-stop gradient resembling diffused softbox studio lighting across satin automotive paint.
- **Architectural Clarity:** Flat, monolithic panels float with absolute mechanical restraint. Surfaces do not rely on aggressive drop shadows; they assert depth through razor-sharp hair-line dividers and luminous surface stratification.
- **Precision Pacing:** High-contrast, near-black ink anchors typographic authority, while electric lime chartreuse serves as a clinical focal point—reserved strictly for live states, active telemetry needles, brand identifiers, and real-time alerts.

## Colors

The system uses a calibrated, high-fidelity light theme:

- **Backdrop Dynamics:** The global canvas transitions seamlessly from `#F6F7F9` at the top down to `#ECEDEF`. Card surfaces are rendered in immaculate `#FFFFFF` to produce an optical lift against the tinted floor.
- **Primary Ink (`#0B0B0C`):** Formulates all core typographic hierarchy, primary interaction targets, and activated navigation pills.
- **Accent Chartreuse (`#D6FF3F`):** Used as a surgical visual cadence. It must never coat expansive surfaces; instead, it energizes micro-badges, brand signifiers, live trace indicators, and primary focal toggles. Text resting on chartreuse must be `#0B0B0C`.
- **Structural Lines:** Structural division utilizes a precise 1px hairline border (`#E8EAED`). When higher contrast containment is required (interactive states, focus boundaries), scale to `#DCDFE4`.
- **Telemetry Semantics:** System states are communicated via triad metrics:
  - Nominal / Calibrated: Emerald (`#10B981`)
  - Threshold Warning / Degradation: Amber (`#F59E0B`)
  - Critical Fault / Disconnect: Crimson (`#EF4444`)

## Typography

The typographical engine leverages a trichotomy of roles:

- **Editorial Presence (Plus Jakarta Sans):** Governs top-tier structural typography, vehicle models, section headlines, and major metric summaries. Its geometric purity conveys sculptural automotive prestige.
- **System Interface (Inter):** Carries contextual body copy, long-form system documentation, dialogues, and form field entries. Calibrated for effortless scanning and functional neutrality.
- **Instrument Telemetry (JetBrains Mono):** Mandated for hex outputs, bus addresses, lap splits, hardware status registers, chassis sensor streams, and micro status chips. Numbers must always render in tabular formatting (`tnum`) to eliminate layout jitter during high-frequency live stream refreshes.

## Layout & Spacing

Layout geometry follows an 8-point structural cadence nested inside a 12-column adaptive grid.

- **Grid Architecture:** 
  - **Desktop (≥ 1280px):** 12 columns, 24px gutters, max-width bounded at 1600px with dynamic outer margins.
  - **Tablet (768px - 1279px):** 8 columns, 16px gutters, 32px safe boundaries.
  - **Mobile (< 768px):** 4 columns, 16px gutters, 20px page gutters. Telemetry blocks collapse into stacked monolithic modules.
- **Rhythm & Padding:** Telemetry clusters employ dense 8px and 12px internal gaps to keep related telemetry streams optically bound. Higher-level showroom presentations use expansive `2rem` to `4rem` vertical intervals to celebrate negative space.

## Elevation & Depth

Visual hierarchy rejects exaggerated, dark drops in favor of low-opacity optical dissipation combined with hairline borders:

- **Base Ambient Layer (Level 0):** Pure white cards (`#FFFFFF`) sitting against the studio gradient (`#F6F7F9` to `#ECEDEF`). Delineated by a 1px solid border in `#E8EAED` without drop shadow.
- **Floating Sensor Card (Level 1):** `box-shadow: 0 1px 3px rgba(11, 11, 12, 0.02), 0 8px 24px -4px rgba(11, 11, 12, 0.04);` enclosed with a 1px `#E8EAED` border.
- **Interactive Hover & Modal Flyouts (Level 2):** `box-shadow: 0 4px 6px -1px rgba(11, 11, 12, 0.03), 0 20px 40px -8px rgba(11, 11, 12, 0.06);` with border transition to `#DCDFE4`.
- **Telemetry HUD Overlays:** Studio-frosted glass execution via `backdrop-filter: blur(16px); background: rgba(255, 255, 255, 0.85);` with an internal `inset 0 0 0 1px rgba(255, 255, 255, 0.6)` highlight edge.

## Shapes

The design system is tuned to `roundedness: 2`:

- **Showroom Cards & Modules:** Fixed rigorously at `16px` (`1rem`). This curvature mirrors the milled radius of bespoke CNC aluminum components and Apple hardware aesthetics.
- **Inputs, Buttons, & Segment Toggles:** Radiused at `8px` (`0.5rem`) for compact, ergonomic tactile targets.
- **Status Indicators, Badges, & Filter Chips:** Fully radiused capsules (`9999px`) to immediately signal transient states, selectable parameters, and hex metadata tags.

## Components

### Buttons
- **Primary:** Solid Near-Black (`#0B0B0C`) fill, crisp `#FFFFFF` text in Inter semi-bold (14px). Flat, no drop shadow. On hover, subtle luminance lift to `#222326`.
- **Accent (Live / Execute):** Solid Chartreuse (`#D6FF3F`) fill, `#0B0B0C` typography. Reserved for immediate real-world actions (e.g., "INITIALIZE DIAGNOSTICS", "DEPLOY MAP").
- **Secondary / Ghost:** `#FFFFFF` background, 1px `#E8EAED` border, `#0B0B0C` typography. On hover, border tint darkens to `#DCDFE4` with an ambient glow.

### Telemetry Cards
- Pure `#FFFFFF` fill with 16px corner radius and hairline `#E8EAED` containment.
- Header zone houses the parameter name in `label-caps` (`JetBrains Mono`, 10px, uppercase, `#8A8F99`) paired with real-time status pulses.
- Central zone delivers the critical read-out in `telemetry-lg` or `headline-lg` with a mono-formatted unit label (e.g., `842 Nm`, `1.42 G`).

### Chips & Badges
- **Status Chips:** Rendered in `radius-pill` with an internal dot (6px) driven by telemetry status colors (`#10B981`, `#F59E0B`, `#EF4444`). Background carries a 10% alpha tint of the respective status color.
- **Hardware & Bus Tags:** Muted fill (`#F6F7F9`), 1px border (`#E8EAED`), text styled in `JetBrains Mono` 11px (`#52555F`).

### Navigation Segmented Controls
- Contained within a shallow track (`#F0F1F3`) with 8px radius.
- Active element utilizes a Near-Black (`#0B0B0C`) pill pill-card with `#FFFFFF` typography.
- Inactive items remain muted `#71747D`, transitioning cleanly on hover.

### Inputs & Sliders
- Inputs feature `#FFFFFF` fill, 1px `#E8EAED` border, and 8px corners. Active focus states replace the border with a sharp 1.5px `#0B0B0C` outline without heavy colored rings.
- Precision sliders use a 2px horizontal track in `#E8EAED` with completed paths filled in `#0B0B0C` and a micro-thumb (14px solid white circle, 1px `#0B0B0C` border).

### Telemetry Stream Strip (Domain-Specific)
- An inline ticker module presenting uninterrupted serial data streams. Features monospaced text (`JetBrains Mono` 11px) with flashing chartreuse cursor blocks for active packet ingestion.